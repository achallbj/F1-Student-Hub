/**
 * F1 Hub — Tier 3: Data Access Layer
 * Version 5: REST API Integration and Extension
 *
 * Handles all communication between the application logic (Tier 2) and
 * data sources (Tier 4). Three new live REST API integrations added in V5:
 *
 *   getWeather()       — Open-Meteo API (Boston weather, no key required)
 *   getExchangeRates() — Open Exchange Rates API (currency conversion, no key required)
 *   getCountryInfo()   — REST Countries API (home country facts, no key required)
 *
 * Design note: Bubble.io's free plan restricts external API calls made from
 * within Bubble server-side workflows. All three V5 integrations are therefore
 * implemented as client-side browser fetch() calls, which are not subject to
 * that restriction. Bubble continues to serve as the Tier 4 database layer
 * for student, task, and resource data.
 *
 * Bubble API base URL (internal data, auth-gated):
 * https://f1hub.bubbleapps.io/api/1.1/obj/
 */

const F1HubAPI = (function () {

  // ── Mock data (Bubble DB layer — V4 baseline) ──────────────────────────
  // These replace live Bubble API responses during development.
  // Bubble free plan blocks external API calls; in production these
  // functions fetch from Bubble's authenticated REST endpoints instead.

  const MOCK_TASKS = [
    {
      task_id: "task-visa",
      title: "Confirm your visa & immigration documents",
      description: "Make sure your passport, visa, and university immigration documents are valid and accessible.",
      due_date: "Before you travel",
      status: "urgent",
      is_completed: false
    },
    {
      task_id: "task-housing",
      title: "Finalize your housing",
      description: "Confirm your residence, move-in date, address, and check-in instructions.",
      due_date: "Before move-in day",
      status: "soon",
      is_completed: false
    },
    {
      task_id: "task-insurance",
      title: "Arrange health insurance",
      description: "Review your university health insurance requirements and complete enrollment if needed.",
      due_date: "Before classes start",
      status: "soon",
      is_completed: false
    },
    {
      task_id: "task-accounts",
      title: "Activate your university accounts",
      description: "Set up your student email, learning platform, and multi-factor authentication.",
      due_date: "Before classes start",
      status: "normal",
      is_completed: false
    },
    {
      task_id: "task-orientation",
      title: "Register for international orientation",
      description: "Sign up for orientation sessions and save the dates for your first campus activities.",
      due_date: "During your first week",
      status: "normal",
      is_completed: false
    }
  ];

  const MOCK_RESOURCES = [
    { title: "Arrival Guide",        description: "Airports, transportation, arrival dates, and getting to campus.", icon: "✈", category: "transit"     },
    { title: "Housing",              description: "Residence options, move-in information, and accommodation advice.", icon: "🏠", category: "housing"     },
    { title: "Immigration Support",  description: "Visas, immigration documents, and maintaining your student status.", icon: "🛂", category: "immigration" },
    { title: "Banking & Money",      description: "Opening a bank account and managing expenses locally.", icon: "💳", category: "finance"    },
    { title: "Health & Wellness",    description: "Healthcare, insurance, counseling, and wellness services.", icon: "🩺", category: "health"     },
    { title: "Student Community",    description: "Clubs, events, cultural groups, and ways to connect with peers.", icon: "🤝", category: "community"  }
  ];

  // ── Internal data methods (Bubble DB layer) ────────────────────────────

  /**
   * Fetch the onboarding checklist for a given student.
   *
   * Production endpoint:
   * GET https://f1hub.bubbleapps.io/api/1.1/obj/task
   *   ?constraints=[{"key":"student","constraint_type":"equals","value":studentId}]
   * Headers: { Authorization: "Bearer <BUBBLE_API_TOKEN>" }
   */
  async function getChecklist(studentId) {
    // TODO: replace mock with live Bubble call
    // const res = await fetch(
    //   `https://f1hub.bubbleapps.io/api/1.1/obj/task?constraints=${
    //     JSON.stringify([{ key: "student", constraint_type: "equals", value: studentId }])
    //   }`,
    //   { headers: { Authorization: `Bearer ${BUBBLE_API_TOKEN}` } }
    // );
    // return await res.json();
    return { results: MOCK_TASKS };
  }

  /**
   * Persist task completion state to the database.
   *
   * Production endpoint:
   * PATCH https://f1hub.bubbleapps.io/api/1.1/obj/task/{taskId}
   * Body: { is_completed: boolean, completed_at: ISO string | null }
   */
  async function saveTaskState(taskId, isCompleted) {
    // TODO: replace mock with live Bubble call
    // await fetch(`https://f1hub.bubbleapps.io/api/1.1/obj/task/${taskId}`, {
    //   method: "PATCH",
    //   headers: {
    //     Authorization: `Bearer ${BUBBLE_API_TOKEN}`,
    //     "Content-Type": "application/json"
    //   },
    //   body: JSON.stringify({
    //     is_completed: isCompleted,
    //     completed_at: isCompleted ? new Date().toISOString() : null
    //   })
    // });
    console.log(`[Tier 3 API] Task ${taskId} saved — completed: ${isCompleted}`);
    return { status: "ok" };
  }

  /**
   * Fetch all available resources.
   *
   * Production endpoint:
   * GET https://f1hub.bubbleapps.io/api/1.1/obj/resource
   */
  async function getResources() {
    // TODO: replace mock with live Bubble call
    return { results: MOCK_RESOURCES };
  }

  /**
   * Authenticate a student via Northeastern SSO.
   * In production, redirects to NEU Shibboleth/SAML endpoint,
   * receives a JWT, and validates it against Bubble.
   */
  async function authenticateStudent(email) {
    // TODO: integrate with NEU SSO
    console.log(`[Tier 3 API] Auth stub called for: ${email}`);
    return {
      student_id: "demo-student-001",
      email,
      program_start_date: "2026-09-09"
    };
  }

  // ── V5: External REST API methods ──────────────────────────────────────
  // All three functions call public APIs directly from the browser.
  // No API keys required. CORS is supported by all three providers.

  /**
   * Integration 1: Boston Weather — Open-Meteo API
   *
   * Fetches current weather conditions at Northeastern University's
   * Boston campus. Open-Meteo is free, open-source, and requires no
   * authentication for standard forecast requests.
   *
   * Endpoint:
   * GET https://api.open-meteo.com/v1/forecast
   *   ?latitude=42.3601           — Northeastern University latitude
   *   &longitude=-71.0589         — Northeastern University longitude
   *   &current_weather=true       — include current conditions block
   *   &temperature_unit=celsius   — base unit (UI converts to °F as needed)
   *   &timezone=America/New_York  — localise timestamps to Boston time
   *   &forecast_days=1            — only today's data
   *
   * Response shape (relevant fields):
   * {
   *   current_weather: {
   *     temperature: number,    // °C
   *     windspeed:   number,    // km/h
   *     weathercode: number     // WMO weather interpretation code
   *   }
   * }
   *
   * WMO weathercode reference: https://open-meteo.com/en/docs#weathervariables
   */
  async function getWeather() {
    const endpoint =
      "https://api.open-meteo.com/v1/forecast" +
      "?latitude=42.3601" +
      "&longitude=-71.0589" +
      "&current_weather=true" +
      "&temperature_unit=celsius" +
      "&timezone=America%2FNew_York" +
      "&forecast_days=1";

    const res = await fetch(endpoint);
    if (!res.ok) throw new Error(`Open-Meteo API error: ${res.status}`);
    return await res.json();
  }

  /**
   * Integration 2: Currency Converter — Open Exchange Rates API
   *
   * Fetches live exchange rates relative to USD. International students
   * frequently need to convert from their home currency when budgeting
   * for tuition, housing, and living expenses.
   *
   * Endpoint:
   * GET https://open.er-api.com/v6/latest/{base}
   *   base — ISO 4217 base currency code (default: "USD")
   *
   * Response shape (relevant fields):
   * {
   *   base_code:    string,            // e.g. "USD"
   *   time_last_update_utc: string,    // ISO timestamp of last rate update
   *   rates: {
   *     [currencyCode: string]: number // exchange rate relative to base
   *   }
   * }
   *
   * Rates update approximately every 24 hours. No key required.
   *
   * @param {string} base — ISO 4217 currency code (default: "USD")
   */
  async function getExchangeRates(base = "USD") {
    const res = await fetch(`https://open.er-api.com/v6/latest/${encodeURIComponent(base)}`);
    if (!res.ok) throw new Error(`Open Exchange Rates API error: ${res.status}`);
    return await res.json();
  }

  /**
   * Integration 3: Home Country Info — REST Countries API
   *
   * Returns metadata about a country by its ISO 3166-1 alpha-2 code.
   * Used to help students compare their home country context (currency,
   * language, time zone) with Boston / the United States before arriving.
   *
   * Endpoint:
   * GET https://restcountries.com/v3.1/alpha/{code}
   *   code — ISO 3166-1 alpha-2 country code (e.g. "tw", "in", "kr")
   *
   * Response shape (relevant fields, first array element):
   * {
   *   name:       { common: string, official: string },
   *   capital:    string[],
   *   flag:       string,        // emoji flag
   *   languages:  { [code]: string },
   *   currencies: { [code]: { name: string, symbol: string } },
   *   timezones:  string[]       // e.g. ["UTC+08:00"]
   * }
   *
   * @param {string} code — ISO 3166-1 alpha-2 country code
   */
  async function getCountryInfo(code) {
    const res = await fetch(`https://restcountries.com/v3.1/alpha/${encodeURIComponent(code)}`);
    if (!res.ok) throw new Error(`REST Countries API error: ${res.status}`);
    const data = await res.json();
    return data[0];
  }

  // Expose public interface
  return {
    // Bubble DB layer (V4 baseline)
    getChecklist,
    saveTaskState,
    getResources,
    authenticateStudent,
    // External REST integrations (V5 new)
    getWeather,
    getExchangeRates,
    getCountryInfo
  };

})();
