/**
 * F1 Hub — AI Assistant Widget
 * Tier 1: Presentation Layer — Conversational UI Component
 *
 * Renders a floating chat button and panel that allows students to ask
 * questions about onboarding tasks in natural language.
 *
 * Current state: mock responses (demonstration mode)
 *
 * Production integration plan:
 *   User message → POST to n8n webhook (Tier 2: Application Logic)
 *   n8n agent queries Bubble DB (Tier 4) for relevant task/resource data
 *   n8n returns contextual response → displayed to student
 *
 * Production n8n webhook:
 *   POST https://[n8n-instance]/webhook/f1hub-assistant
 *   Body: { message: string, studentId: string }
 *   Response: { response: string }
 */

(function () {

  // ── Mock responses ────────────────────────────────────────────────────────
  // Replace getAssistantResponse() with a live n8n webhook call in production.

  const RESPONSES = {
    sevis:     "For SEVIS check-in, visit the Office of Global Services (OGS) within 30 days of arriving in the US. Bring your passport, I-20, and visa. OGS is located at 125 Richards Hall.",
    housing:   "Log into the Housing Portal at housing.northeastern.edu to view your room assignment, move-in date, and check-in instructions.",
    insurance: "Northeastern requires all students to have health insurance. Enroll in or waive the university plan (UHCS) before the semester deadline at studenthealth.northeastern.edu.",
    transit:   "Get a CharlieCard at any MBTA station, then register it online at mbta.com for the student discount and remote reloading.",
    default:   "I can help with SEVIS check-in, housing setup, health insurance enrollment, and MBTA transit. What would you like to know?"
  };

  function getMockResponse(message) {
    const m = message.toLowerCase();
    if (m.includes("sevis") || m.includes("immigration") || m.includes("visa")) return RESPONSES.sevis;
    if (m.includes("housing") || m.includes("room") || m.includes("dorm"))      return RESPONSES.housing;
    if (m.includes("insurance") || m.includes("health") || m.includes("uhcs"))  return RESPONSES.insurance;
    if (m.includes("transit") || m.includes("mbta") || m.includes("charlie") || m.includes("bus") || m.includes("train")) return RESPONSES.transit;
    return RESPONSES.default;
  }

  // Production API call (replace getMockResponse with this):
  //
  // async function getAssistantResponse(message, studentId) {
  //   const res = await fetch("https://[n8n-instance]/webhook/f1hub-assistant", {
  //     method: "POST",
  //     headers: { "Content-Type": "application/json" },
  //     body: JSON.stringify({ message, studentId })
  //   });
  //   const data = await res.json();
  //   return data.response;
  // }

  // ── Styles ────────────────────────────────────────────────────────────────

  const styles = `
    #f1-chat-widget { position: fixed; bottom: 24px; right: 24px; z-index: 999; font-family: Inter, -apple-system, sans-serif; }
    #f1-chat-toggle { width: 54px; height: 54px; border-radius: 50%; background: #a3162a; color: #fff; border: none; font-size: 1.4rem; cursor: pointer; box-shadow: 0 4px 18px rgba(0,0,0,0.2); transition: transform 0.2s ease; display: flex; align-items: center; justify-content: center; }
    #f1-chat-toggle:hover { transform: scale(1.08); }
    #f1-chat-toggle:focus-visible { outline: 3px solid #fff; outline-offset: 3px; }
    #f1-chat-panel { display: none; position: absolute; bottom: 66px; right: 0; width: 320px; background: #fff; border-radius: 14px; box-shadow: 0 8px 32px rgba(7,29,59,0.16); border: 1px solid #e4e7ec; overflow: hidden; }
    #f1-chat-panel.open { display: block; }
    #f1-chat-header { background: #071d3b; color: #fff; padding: 13px 16px; display: flex; justify-content: space-between; align-items: center; font-weight: 700; font-size: 0.88rem; }
    #f1-chat-close { background: none; border: none; color: #fff; cursor: pointer; font-size: 1rem; line-height: 1; padding: 4px; }
    #f1-chat-close:focus-visible { outline: 2px solid #fff; border-radius: 4px; }
    #f1-chat-messages { height: 240px; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 10px; }
    .f1-msg { max-width: 86%; padding: 9px 13px; border-radius: 10px; font-size: 0.84rem; line-height: 1.55; }
    .f1-msg.user { align-self: flex-end; background: #a3162a; color: #fff; border-radius: 10px 10px 2px 10px; }
    .f1-msg.bot  { align-self: flex-start; background: #f0f2f5; color: #172033; border-radius: 10px 10px 10px 2px; }
    #f1-chat-footer { display: flex; gap: 8px; padding: 11px 12px; border-top: 1px solid #e4e7ec; }
    #f1-chat-input { flex: 1; border: 1px solid #d0d5dd; border-radius: 8px; padding: 8px 10px; font-size: 0.84rem; font-family: inherit; outline: none; }
    #f1-chat-input:focus { border-color: #a3162a; }
    #f1-chat-send { background: #a3162a; color: #fff; border: none; border-radius: 8px; padding: 8px 14px; font-size: 0.84rem; font-weight: 700; cursor: pointer; font-family: inherit; }
    #f1-chat-send:hover { background: #7f1020; }
    #f1-chat-send:focus-visible { outline: 3px solid #a3162a; outline-offset: 2px; }
  `;

  // ── HTML ──────────────────────────────────────────────────────────────────

  const html = `
    <div id="f1-chat-widget">
      <button id="f1-chat-toggle" aria-label="Open F1 Hub assistant" aria-expanded="false" aria-controls="f1-chat-panel">
        <span aria-hidden="true">💬</span>
      </button>
      <div id="f1-chat-panel" role="dialog" aria-label="F1 Hub AI assistant" aria-modal="false">
        <div id="f1-chat-header">
          <span>F1 Hub Assistant</span>
          <button id="f1-chat-close" aria-label="Close assistant">✕</button>
        </div>
        <div id="f1-chat-messages" role="log" aria-live="polite" aria-label="Chat messages"></div>
        <div id="f1-chat-footer">
          <input type="text" id="f1-chat-input" placeholder="Ask about SEVIS, housing, insurance..." aria-label="Type your question" />
          <button id="f1-chat-send">Send</button>
        </div>
      </div>
    </div>
  `;

  // ── Mount ─────────────────────────────────────────────────────────────────

  const styleEl = document.createElement("style");
  styleEl.textContent = styles;
  document.head.appendChild(styleEl);

  const wrapper = document.createElement("div");
  wrapper.innerHTML = html;
  document.body.appendChild(wrapper);

  // ── Widget logic ──────────────────────────────────────────────────────────

  const toggle   = document.getElementById("f1-chat-toggle");
  const panel    = document.getElementById("f1-chat-panel");
  const closeBtn = document.getElementById("f1-chat-close");
  const input    = document.getElementById("f1-chat-input");
  const sendBtn  = document.getElementById("f1-chat-send");
  const messages = document.getElementById("f1-chat-messages");

  function addMessage(text, sender) {
    const msg = document.createElement("div");
    msg.className = `f1-msg ${sender}`;
    msg.textContent = text;
    messages.appendChild(msg);
    messages.scrollTop = messages.scrollHeight;
  }

  function openChat() {
    panel.classList.add("open");
    toggle.setAttribute("aria-expanded", "true");
    if (messages.children.length === 0) {
      addMessage("Hi! I'm your F1 Hub assistant. I can help with SEVIS check-in, housing, health insurance, and MBTA transit. What do you need help with?", "bot");
    }
    input.focus();
  }

  function closeChat() {
    panel.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.focus();
  }

  async function sendMessage() {
    const text = input.value.trim();
    if (!text) return;

    addMessage(text, "user");
    input.value = "";
    sendBtn.disabled = true;

    // Simulate network latency (remove in production)
    await new Promise(r => setTimeout(r, 600));

    // Production: replace getMockResponse with a live n8n API call
    const response = getMockResponse(text);
    addMessage(response, "bot");
    sendBtn.disabled = false;
    input.focus();
  }

  toggle.addEventListener("click", () =>
    panel.classList.contains("open") ? closeChat() : openChat()
  );
  closeBtn.addEventListener("click", closeChat);
  sendBtn.addEventListener("click", sendMessage);
  input.addEventListener("keydown", e => { if (e.key === "Enter") sendMessage(); });

})();
