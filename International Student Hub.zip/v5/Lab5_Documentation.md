# Lab Exercise 5: REST API Integration and Extension (Version 5)
**F1 Hub — International Student Transition Hub**
Group 8 | ITC 6250 | Module 6

---

## API Overview

Version 5 adds three live REST API integrations to the F1 Hub front end.
All three are implemented as client-side `fetch()` calls in the browser,
which bypasses the Bubble.io free-plan restriction that blocks external API
calls made from within Bubble's server-side workflow engine. The Bubble
database layer (Student, Task, Resource data types) remains unchanged
from Version 4.

| # | API | Provider | Endpoint | Method | Auth |
|---|-----|----------|----------|--------|------|
| 1 | Open-Meteo (Boston weather) | open-meteo.com | `/v1/forecast` | GET | None |
| 2 | Open Exchange Rates (currency) | open.er-api.com | `/v6/latest/USD` | GET | None |
| 3 | REST Countries (home country info) | restcountries.com | `/v3.1/alpha/{code}` | GET | None |

---

## Integration 1: Boston Weather (Open-Meteo)

**Endpoint:**
```
GET https://api.open-meteo.com/v1/forecast
  ?latitude=42.3601
  &longitude=-71.0589
  &current_weather=true
  &temperature_unit=celsius
  &timezone=America/New_York
  &forecast_days=1
```

**User workflow supported:**
International students preparing to travel to Boston need to understand
New England's climate before they pack. The weather widget displays the
current temperature (in both Celsius and Fahrenheit), a plain-language
weather description mapped from WMO weather codes, and current wind speed.

**Key response fields used:**
- `current_weather.temperature` — current temperature in °C (converted to °F in the UI)
- `current_weather.windspeed` — wind speed in km/h
- `current_weather.weathercode` — WMO code mapped to a label and emoji in `widgets.js`

---

## Integration 2: Currency Converter (Open Exchange Rates)

**Endpoint:**
```
GET https://open.er-api.com/v6/latest/USD
```

**User workflow supported:**
Students arriving from Taiwan, India, South Korea, and other countries
routinely convert their home currency to USD when budgeting for tuition,
housing deposits, and daily expenses. The converter accepts a user-entered
amount, a home currency selected from a dropdown (13 currencies covering
the most common student origins at Northeastern), and displays the USD
equivalent in real time. Exchange rates update approximately every 24
hours; the last-updated date is displayed alongside the rate.

**Key response fields used:**
- `rates` — object of ISO 4217 currency codes mapped to their rate per 1 USD
- `time_last_update_utc` — timestamp displayed to communicate data freshness

---

## Integration 3: Home Country Info (REST Countries)

**Endpoint:**
```
GET https://restcountries.com/v3.1/alpha/{code}
```
where `{code}` is the ISO 3166-1 alpha-2 country code selected by the user
(e.g., `tw` for Taiwan, `in` for India).

**User workflow supported:**
Students often encounter unfamiliar differences when they first arrive: a
different currency, a different primary language in day-to-day services,
and time zone disorientation when calling home. The Home Country widget
lets a student select their home country from a dropdown and instantly
see: country name and flag, capital, official language(s), home currency,
and home time zone — alongside a reminder that Boston operates on
America/New_York (UTC−5 in winter, UTC−4 during daylight saving time).

**Key response fields used:**
- `name.common` — country common name
- `capital` — capital city array
- `flag` — emoji flag character
- `languages` — key-value object of official languages
- `currencies` — key-value object including currency name and symbol
- `timezones` — array of UTC offset strings

---

## Challenges and Solutions

**Challenge 1: Bubble free-plan API restriction**
Bubble.io's free plan does not allow external API calls from within Bubble
server-side workflows. The original architecture planned for the front end
to read data by calling Bubble's REST API directly. This was not feasible
without upgrading to a paid plan.

*Solution:* All three V5 integrations make calls directly from the browser
using the native `fetch()` API. Because the calls originate from the
client rather than from a Bubble workflow, the platform restriction does
not apply. This approach also reduces latency since responses go directly
to the browser rather than routing through Bubble's servers.

**Challenge 2: CORS compatibility**
Not all public APIs allow cross-origin requests from browser JavaScript.
APIs that do not include an `Access-Control-Allow-Origin` header will be
blocked by the browser before the response is received.

*Solution:* All three selected APIs explicitly support CORS for browser
clients. This was confirmed before selection; APIs that required a server-
side proxy were excluded.

**Challenge 3: Graceful degradation on API failure**
Live API calls can fail due to network issues, rate limits, or third-party
downtime. A failed fetch must not break the rest of the page.

*Solution:* Each widget wraps its API call in a try/catch block. On error,
the widget displays a user-friendly message ("Could not load weather data.
Check your connection.") without affecting the checklist, resources, or
chatbot sections. A loading animation runs during the fetch and is removed
when data arrives or an error is caught.

---

## Reflection (Design Thinking and LCNC vs. Traditional Coding)

Design thinking shaped our API planning from the first question: not "what
data can we fetch?" but "what does an international student arriving in
Boston actually need before they land?" That reframe surfaced three genuine
pain points — weather anxiety about New England winters, currency confusion
when wiring money for a housing deposit, and time zone and cultural
disorientation when calling home. Each of the three integrations maps
directly to a real student workflow rather than being a technical
demonstration for its own sake.

Comparing LCNC tools and traditional coding in this lab made the tradeoff
unusually clear. Bubble.io's visual data binding and option-set workflow
handled the database and CRUD layer quickly in Version 4, but its free-
tier restriction blocked the external API calls we needed for Version 5.
Writing the same integrations in plain JavaScript with `fetch()` required
no platform, no drag-and-drop configuration, and no cost — just three
well-documented functions in `api.js` and a matching widget file. The
lesson is that LCNC tools are highly efficient when a task fits within the
platform's abstraction layer, but traditional coding regains the advantage
the moment that boundary is crossed. Future projects will benefit from
mapping those boundaries explicitly before committing to a tool stack.

---

*Word count (reflection): ~195 words*
