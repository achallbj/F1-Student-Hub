/**
 * F1 Hub — Tier 2: Application Logic Layer
 *
 * Contains all business rules and workflows:
 *   - Task state management and rendering
 *   - Progress bar calculation
 *   - Badge assignment logic
 *   - localStorage session cache management
 *   - Coordination with Tier 3 (F1HubAPI) for data persistence
 *
 * Depends on: F1HubAPI (tier3_data_access/api.js) — must load first
 * Called by:  Tier 1 event handlers (index.html)
 */

const STORAGE_KEY = "f1hub-checklist";

// ── DOM references ────────────────────────────────────────────────────────
const checkboxes    = document.querySelectorAll(".task-checkbox");
const progressFill  = document.getElementById("progressFill");
const progressText  = document.getElementById("progressText");
const progressTrack = document.querySelector(".progress-track");

// ── Session cache (localStorage) ─────────────────────────────────────────

/**
 * Load task states from the localStorage session cache.
 * Falls back to an empty object if storage is unavailable or data is corrupt.
 * The authoritative record lives in Tier 4 (Bubble DB) via F1HubAPI.
 */
function loadSessionCache() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
  } catch (e) {
    return {};
  }
}

/**
 * Write current task states to localStorage session cache.
 * This is a fast-path write; the full persist goes to Tier 4 via Tier 3.
 */
function saveSessionCache() {
  try {
    const state = {};
    checkboxes.forEach(cb => { state[cb.id] = cb.checked; });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    /* Storage unavailable: checklist still works for this session */
  }
}

// ── Business logic: task rendering ───────────────────────────────────────

/**
 * Render a single task's visual state based on its checkbox status.
 *
 * Badge labels and CSS classes are driven by data-status and data-label
 * attributes on the task element, keeping the logic data-driven rather
 * than relying on hardcoded index positions.
 */
function renderTask(checkbox) {
  const task  = checkbox.closest(".task");
  const badge = task.querySelector(".badge");

  if (checkbox.checked) {
    task.classList.add("completed");
    badge.textContent = "Completed";
    badge.className   = "badge done";
  } else {
    task.classList.remove("completed");
    badge.textContent = task.dataset.label;
    badge.className   = "badge " + task.dataset.status;
  }
}

// ── Business logic: progress calculation ─────────────────────────────────

/**
 * Recalculate and render the progress bar and summary text.
 * Updates ARIA attributes for screen reader accessibility (WCAG 4.1.3).
 */
function updateProgress() {
  const total     = checkboxes.length;
  const completed = Array.from(checkboxes).filter(cb => cb.checked).length;
  const summary   = completed === total
    ? `All ${total} completed`
    : `${completed} of ${total} completed`;

  progressFill.style.width = (completed / total) * 100 + "%";
  progressTrack.setAttribute("aria-valuenow",  completed);
  progressTrack.setAttribute("aria-valuetext", summary);

  progressText.innerHTML = completed === total
    ? `${summary} <span aria-hidden="true">🎉</span>`
    : summary;
}

// ── Event handling ────────────────────────────────────────────────────────

/**
 * Handle checkbox change:
 *   1. Update UI immediately (optimistic update)
 *   2. Persist to session cache (fast)
 *   3. Sync to Tier 3 → Tier 4 (authoritative record)
 */
async function handleTaskChange(checkbox) {
  renderTask(checkbox);
  updateProgress();
  saveSessionCache();

  // Sync authoritative state to Bubble DB via Tier 3 Data Access layer
  await F1HubAPI.saveTaskState(checkbox.id, checkbox.checked);
}

// ── Initialisation ────────────────────────────────────────────────────────

/**
 * On page load:
 *   1. Attempt fast restore from localStorage session cache
 *   2. (Production) Fetch authoritative state from Tier 3 API to override cache
 *   3. Render all tasks and bind event listeners
 */
(async function init() {

  const cached = loadSessionCache();

  // Production path: fetch authoritative task state from Bubble via Tier 3.
  // Uncomment to enable live data sync:
  //
  // try {
  //   const student = await F1HubAPI.authenticateStudent(currentUserEmail);
  //   const { results } = await F1HubAPI.getChecklist(student.student_id);
  //   results.forEach(task => { cached[task.task_id] = task.is_completed; });
  // } catch (e) {
  //   console.warn("[Tier 2] Could not fetch from API, using session cache.");
  // }

  checkboxes.forEach(checkbox => {
    checkbox.checked = Boolean(cached[checkbox.id]);
    renderTask(checkbox);
    checkbox.addEventListener("change", function () {
      handleTaskChange(this);
    });
  });

  updateProgress();

})();
