/**
 * F1 Hub — Version 5: Live API Widgets
 * Tier 1: Presentation Layer — Live Data Components
 *
 * Initialises three REST-powered widgets by calling F1HubAPI (Tier 3):
 *
 *   Widget 1 — Boston Weather    (Open-Meteo, no key required)
 *   Widget 2 — Currency Converter (Open Exchange Rates, no key required)
 *   Widget 3 — Home Country Info  (REST Countries, no key required)
 *
 * All API calls are client-side browser fetch() requests. This bypasses
 * the Bubble.io free-plan restriction that blocks external calls made
 * from within Bubble's own server-side workflow engine.
 *
 * Depends on: F1HubAPI (api.js) — must load before this script.
 */

// ── Helper: WMO weather code → label + emoji ─────────────────────────────
// Reference: https://open-meteo.com/en/docs#weathervariables

function parseWeatherCode(code) {
  if (code === 0)   return { label: "Clear sky",     icon: "☀️"  };
  if (code <= 3)    return { label: "Partly cloudy", icon: "⛅"  };
  if (code <= 48)   return { label: "Foggy",         icon: "🌫️" };
  if (code <= 55)   return { label: "Drizzle",       icon: "🌦️" };
  if (code <= 65)   return { label: "Rain",          icon: "🌧️" };
  if (code <= 77)   return { label: "Snow",          icon: "❄️"  };
  if (code <= 82)   return { label: "Rain showers",  icon: "🌦️" };
  if (code <= 86)   return { label: "Snow showers",  icon: "🌨️" };
  return             { label: "Thunderstorm",        icon: "⛈️" };
}

// ── Helper: generic widget error display ─────────────────────────────────

function showWidgetError(cardId, message) {
  const card = document.getElementById(cardId);
  if (!card) return;
  const body = card.querySelector(".widget-body");
  if (body) {
    body.innerHTML = `<div class="widget-error-state"><span aria-hidden="true">⚠️</span><p>${message}</p></div>`;
  }
}

// ── Widget 1: Boston Weather ──────────────────────────────────────────────

async function initWeatherWidget() {
  try {
    const data = await F1HubAPI.getWeather();
    const cw   = data.current_weather;
    const { label, icon } = parseWeatherCode(cw.weathercode);
    const tempC = cw.temperature.toFixed(1);
    const tempF = ((cw.temperature * 9 / 5) + 32).toFixed(1);

    document.getElementById("weatherIcon").textContent      = icon;
    document.getElementById("weatherTemp").textContent      = `${tempC}°C / ${tempF}°F`;
    document.getElementById("weatherDesc").textContent      = label;
    document.getElementById("weatherWind").textContent      = `${cw.windspeed} km/h`;

    document.getElementById("weatherCard").classList.remove("widget-loading");
  } catch (err) {
    console.error("[Widget 1] Weather API error:", err);
    showWidgetError("weatherCard", "Could not load weather data. Check your connection.");
  }
}

// ── Widget 2: Currency Converter ──────────────────────────────────────────

let exchangeRates    = null;
let ratesLastUpdated = null;

async function initCurrencyWidget() {
  try {
    const data       = await F1HubAPI.getExchangeRates("USD");
    exchangeRates    = data.rates;
    ratesLastUpdated = data.time_last_update_utc
      ? new Date(data.time_last_update_utc).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
      : null;

    document.getElementById("currencyCard").classList.remove("widget-loading");
    convertCurrency(); // render initial result
  } catch (err) {
    console.error("[Widget 2] Exchange rate API error:", err);
    showWidgetError("currencyCard", "Could not load exchange rates. Check your connection.");
  }
}

function convertCurrency() {
  if (!exchangeRates) return;

  const amount    = parseFloat(document.getElementById("currencyAmount").value) || 0;
  const fromCode  = document.getElementById("currencyFrom").value;
  const rate      = exchangeRates[fromCode]; // units of fromCode per 1 USD

  if (!rate) return;

  const usdResult = amount / rate;
  document.getElementById("currencyResult").textContent =
    usdResult.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const rateDisplay = rate >= 1
    ? `1 USD ≈ ${rate.toLocaleString("en-US", { maximumFractionDigits: 2 })} ${fromCode}`
    : `1 ${fromCode} ≈ ${(1 / rate).toLocaleString("en-US", { maximumFractionDigits: 4 })} USD`;

  document.getElementById("currencyRate").textContent =
    rateDisplay + (ratesLastUpdated ? ` · Rates as of ${ratesLastUpdated}` : "");
}

// ── Widget 3: Home Country Info ────────────────────────────────────────────

async function loadCountryInfo(code) {
  const panel = document.getElementById("countryPanel");
  panel.innerHTML = `<p class="widget-loading-text">Loading...</p>`;

  try {
    const country = await F1HubAPI.getCountryInfo(code);

    const flag       = country.flag || "🏳";
    const name       = country.name?.common || "—";
    const capital    = (country.capital || []).join(", ") || "—";
    const langs      = Object.values(country.languages || {}).join(", ") || "—";
    const currencies = Object.entries(country.currencies || {})
      .map(([c, info]) => `${info.name} (${c}${info.symbol ? " · " + info.symbol : ""})`)
      .join(", ") || "—";
    const tz = (country.timezones || ["—"])[0];

    panel.innerHTML = `
      <div class="country-flag" aria-hidden="true">${flag}</div>
      <dl class="country-facts">
        <div class="fact-row">
          <dt>Country</dt>
          <dd>${name}</dd>
        </div>
        <div class="fact-row">
          <dt>Capital</dt>
          <dd>${capital}</dd>
        </div>
        <div class="fact-row">
          <dt>Language(s)</dt>
          <dd>${langs}</dd>
        </div>
        <div class="fact-row">
          <dt>Currency</dt>
          <dd>${currencies}</dd>
        </div>
        <div class="fact-row">
          <dt>Time zone</dt>
          <dd>${tz}</dd>
        </div>
      </dl>
      <p class="country-note">
        → Boston is <strong>America/New_York</strong> (UTC−5 Nov–Mar, UTC−4 Mar–Nov)
      </p>
    `;
  } catch (err) {
    console.error("[Widget 3] REST Countries API error:", err);
    panel.innerHTML = `<p class="widget-error-text">⚠️ Could not load country data.</p>`;
  }
}

// ── Initialise all widgets on DOM ready ──────────────────────────────────

document.addEventListener("DOMContentLoaded", () => {

  // Widget 1: weather (fires-and-forgets; error handled inside)
  initWeatherWidget();

  // Widget 2: currency
  initCurrencyWidget();
  document.getElementById("currencyAmount")?.addEventListener("input",  convertCurrency);
  document.getElementById("currencyFrom")?.addEventListener("change",   convertCurrency);

  // Widget 3: country (load initial selection, update on change)
  const countrySelect = document.getElementById("countrySelect");
  if (countrySelect) {
    loadCountryInfo(countrySelect.value);
    countrySelect.addEventListener("change", () => loadCountryInfo(countrySelect.value));
  }

});
